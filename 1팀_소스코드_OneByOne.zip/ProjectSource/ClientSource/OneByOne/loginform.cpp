#include "loginform.h"
#include "ui_loginform.h"

#include <QMessageBox>
#include <QStackedWidget>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QEventLoop>
#include <QMessageBox>


LoginForm::LoginForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LoginForm)
{
    ui->setupUi(this);

    ui->verticalSpacer_3->changeSize(20, 70);
    ui->verticalSpacer_4->changeSize(20, 50);
    ui->verticalSpacer_5->changeSize(20, 10);
    ui->horizontalSpacer_3->changeSize(10, 18);

    QString image1(tr(":/trademark/D11.png"));
    ui->label->setPixmap(image1);

    ui->loginToolButton->setShortcut(Qt::Key_Return);   // 엔터를 눌렀을 때도 loginToolButton이 활성화되도록 설정
}

LoginForm::~LoginForm()
{
    delete ui;
}

/* loginToolButton을 클릭했을 때 실행되는 슬롯 */
void LoginForm::on_loginToolButton_clicked()
{
#if 0
    QString DoctorID = ui->idLineEdit->text();  // 로그인 ID
    QString password = ui->passwordLineEdit->text();    // 로그인 비밀번호

    if(DoctorID == "osstem1" && password == "1234") {   // 입력한 ID와 비밀번호가 일치할 경우
        emit sig_loginSuccess(1);   // mainWidow로 이동
        emit sig_idInfo(DoctorID);  // 로그인 ID를 시그널로 전달
        //        qobject_cast<QWidget*>(parent())->setGeometry(250, 70, 1350, 885);
        qobject_cast<QWidget*>(parent())->showMaximized();  // 로그인 했을 때 최대창으로 출력
    }

    else if(DoctorID == "osstem2" && password == "5678") {  // 입력한 ID와 비밀번호가 일치할 경우
        emit sig_loginSuccess(1);   // mainWidow로 이동
        emit sig_idInfo(DoctorID);  // 로그인 ID를 시그널로 전달
        qobject_cast<QWidget*>(parent())->showMaximized();  // 로그인 했을 때 최대창으로 출력
    }
    else    // 입력한 ID와 비밀번호가 일치하지 않는 경우
        QMessageBox::information(this, "Login", "다시 시도해주세요.");  // "다시 시도해주세요" 팝업창을 띄움
#else
    QString DoctorID = ui->idLineEdit->text();
    QString password = ui->passwordLineEdit->text();


    QNetworkAccessManager mgr;                                                      // 로그인 정보 접근 매니저
    QEventLoop eventLoop;                                                           // 동기화 변수
    QNetworkRequest req( QUrl( QString("http://" + hostName + ":" + portNum + "/api/login/") ) );   // 로그인 URL
    QNetworkReply *reply = mgr.get(req);                                            // URL을 Get으로 요청

    connect(&mgr, SIGNAL(finished(QNetworkReply *)), &eventLoop, SLOT(quit()));     // 동기화
    eventLoop.exec( );           // "finished( )" 가 호출 될때까지 블록

    if (reply->error( ) == QNetworkReply::NoError) {
        QString strReply = (QString)reply->readAll( );                              // 전체 로그인 Json 정보 읽기

        QJsonDocument jsonResponse =
                QJsonDocument::fromJson(strReply.toUtf8( ));                        // Json 포멧

        QJsonArray jsonArr = jsonResponse["response"].toArray();                    // "response" 배열 안 Json 데이터 파싱
        int ArrCount = jsonArr.size();                                              // ArrCount 변수를 전체 사이즈로 할당

        for(int i = 0; i < jsonArr.size(); i++) {
            QJsonObject patientObj = jsonArr.at(i).toObject();    //jsonResponse.object();

            QString findID = patientObj["_id"].toString();                          // 로그인 정보 아이디 변수 할당
            QString findDoctorID = patientObj["DoctorID"].toString();               // 의사 아이디 변수 할당
            QString findDoctorName = patientObj["DoctorName"].toString();           // 의사 성함 변수 하랑
            QString findPassword = patientObj["Password"].toString();               // 의사 비밀번호 변수


            if(findDoctorID == DoctorID){                                           // 찾고자 하는 아이디가 일치하고,
                if(findPassword == password){                                       // 비밀번호가 일치하면
                    emit sig_loginSuccess(1); // mainWidow로 이동
                    emit sig_idInfo(DoctorID);  // 로그인 ID를 시그널로 전달
                    qobject_cast<QWidget*>(parent())->showMaximized();  // 로그인 했을 때 최대창으로 출력
                }
                else{
                    ArrCount--;                                         // 비밀번호 실패 시 1씩 감소
                }
            }
            else {
                ArrCount--;                                             // 로그인 실패 시 1씩 감소
            }
        }
        if(ArrCount == 0){                                               // ArrCount가 0이면
            QMessageBox::information(this, "Login", "다시 시도해주세요.");  // "다시 시도해주세요" 팝업창을 띄움
        }
    }
    delete reply;
#endif
}

/* logoutPushButton을 클릭했을 때 실행되는 슬롯 */
void LoginForm::slot_logClear()
{
    ui->idLineEdit->clear();    // idLineEidt 초기화
    ui->passwordLineEdit->clear();  // passwordLineEdit 초기화
}

